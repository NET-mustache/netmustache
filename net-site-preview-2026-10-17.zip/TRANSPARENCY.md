NET Transparency Log

This document records public transparency updates for Nietzsche’s Mustache (NET).

The purpose is simple:

* Build slowly
* Document clearly
* Avoid false promises
* Keep public actions visible
* Protect long-term trust

Token Information

* Name: Nietzsche’s Mustache
* Ticker: NET
* Chain: Solana
* Token Address: 5pZDTusrC2s16i9Zw8SHFnL4ew4R9C6G5kwmD6vWpump
* Origin: Pump.fun
* Website: https://netmustache.xyz

Builder Statement

NET is being built as a slow and transparent meme token project on Solana.

The project is not being built with artificial hype, false promises, or guaranteed return claims. The goal is to document public actions clearly and keep the project history visible.

The builder has publicly stated that personal funds have been used to support the project, liquidity, burns, platform fees, and long-term development.

Burn Records

Burn records should be documented here with transaction links whenever possible.

Date	Amount Burned	Transaction Link	Notes
Verified 2026-10-17	71,000,002.366453 NET (seven listed transactions)	[BURNS.md](./BURNS.md)	Earlier 100 million claim remains incompletely reconciled

Liquidity Records

Liquidity actions should be documented here with transaction links whenever possible.

Date	Pool	Amount Added	Transaction Link	Notes
To be added	NET/SOL	To be added	To be added	Liquidity support

Public Wallets

Project-related public wallets may be listed in a separate file:

WALLETS.md

Only public wallet addresses should be shared.

Never upload private keys, seed phrases, API keys, wallet backup files, .env files, or personal access information.

Third-Party Platform Notes

NET visibility across third-party platforms may depend on platform indexing, liquidity, trading activity, pair detection, and each platform’s internal systems.

This repository does not guarantee that any third-party platform will list, display, rank, verify, or maintain NET visibility.

Disclaimer

This document is for transparency only.

It is not financial advice.
It is not a promise of profit.
It is not a guarantee of future price movement, exchange listing, liquidity, visibility, or market cap.

Every participant is responsible for their own decisions.


## Evidence correction — 17 October 2026

The seven transactions in BURNS.md were verified directly against finalized Solana RPC responses. Their subtotal is **71,000,002.366453 NET**. The earlier 100,000,000 NET statement is not fully supported by that list; 28,999,997.633547 NET remains unreconciled relative to that claim. This does not establish that additional burns did not occur.

- [Transaction-by-transaction evidence](./evidence/2026-10-17/burn-summary.json)
- [Saved finalized mint response](./evidence/2026-10-17/mint.json)
- [Local replay of saved evidence](./tools/verify_burns.py)

Observed total supply at finalized slot 458133360: **899,027,267.092872 NET**, with mint and freeze authorities null. Total supply is not circulating supply. This is a dated snapshot, not a complete audit of holders, liquidity control or historical actions.

The website redesign in `site/` is a **local preview**, not a published update to netmustache.xyz. No wallet transaction, bot activation or new paid infrastructure was performed as part of this maintenance work.
