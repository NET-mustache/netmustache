Nietzsche’s Mustache — NET

Nietzsche’s Mustache (NET) is a community-driven meme token on Solana.

It is not a bank.
It is not a protocol.
It is not a yield promise.
It is a transparent, philosophical, and ironic experiment in crypto culture.

Token Information

* Name: Nietzsche’s Mustache
* Ticker: NET
* Chain: Solana
* Token Address: 5pZDTusrC2s16i9Zw8SHFnL4ew4R9C6G5kwmD6vWpump
* Origin: Pump.fun
* Website: https://netmustache.xyz

Purpose

NET was created as a response to the absurdity of crypto markets.

Markets move.
Narratives rise and collapse.
Liquidity appears and disappears.
Most tokens disappear quickly.

NET is being built slowly, transparently, and on-chain.

Transparency

This repository will be used to document:

* Token information
* Burn records
* Liquidity actions
* Public wallet information
* Project updates
* Community-facing roadmap

Core Principle

No false promises.
No guaranteed returns.
No artificial hype.

Only slow building, public records, and long-term discipline.

God is dead. Liquidity is alive.

Disclaimer

NET is a meme token and a high-risk crypto asset.

Nothing in this repository is financial advice.
Nothing here should be understood as a promise of profit, price performance, listing, or future value.

Every participant is responsible for their own decisions.
## Public Records

The main public records for NET are documented here:

- [Transparency Log](./TRANSPARENCY.md)
- [Tokenomics](./TOKENOMICS.md)
- [Burn Records](./BURNS.md)
- [Liquidity Records](./LIQUIDITY.md)
- [Staking Records](./STAKING.md)
- [Public Wallets](./WALLETS.md)
- [Roadmap](./ROADMAP.md)
- [Disclaimer](./DISCLAIMER.md)

## Current development snapshot

- [Website redesign source](./site/index.html) — local preview; not yet deployed to the official domain.
- [Verified listed-burn evidence](./evidence/2026-10-17/burn-summary.json) — dated 17 October 2026.
- [Evidence replay script](./tools/verify_burns.py) — reads saved RPC responses; no signing or transaction execution.

Run the preview locally from this repository:

```sh
python3 -m http.server 8767 --bind 127.0.0.1 --directory site
```

Open http://127.0.0.1:8767/ in your browser.

Replay the recorded burn verification:

```sh
python3 tools/verify_burns.py evidence/2026-10-17
```
