#!/usr/bin/env python3
"""Reconcile saved finalized RPC transactions. This script cannot sign or send transactions."""
import datetime
import decimal
import json
import pathlib
import sys

MINT = "5pZDTusrC2s16i9Zw8SHFnL4ew4R9C6G5kwmD6vWpump"
root = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else "evidence/2026-10-17")
records = json.loads((root / "burn-verification.json").read_text())
rows, seen, raw_total = [], set(), 0
for index, entry in enumerate(records["records"], 1):
    signature = entry["signature"]
    assert signature not in seen, "Duplicate transaction"
    seen.add(signature)
    response = json.loads((root / f"burn-{index}.json").read_text())
    tx = response.get("result")
    assert tx and not tx["meta"]["err"], "Missing or failed transaction"
    assert signature in tx["transaction"]["signatures"], "Signature mismatch"
    instructions = tx["transaction"]["message"]["instructions"] + [
        item
        for group in tx["meta"].get("innerInstructions", [])
        for item in group["instructions"]
    ]
    total = 0
    for instruction in instructions:
        parsed = instruction.get("parsed", {})
        info = parsed.get("info", {})
        if parsed.get("type") not in ("burn", "burnChecked") or info.get("mint") != MINT:
            continue
        assert instruction.get("programId") == "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb", "Unexpected token program"
        amount = info.get("tokenAmount")
        if amount:
            assert amount["decimals"] == 6, "Unexpected decimals"
            total += int(amount["amount"])
        else:
            total += int(info["amount"])
    assert total > 0, "Transaction does not contain the expected NET burn"
    raw_total += total
    rows.append({
        "signature": signature,
        "amount_net": str(decimal.Decimal(total) / 1_000_000),
        "date_utc": datetime.datetime.fromtimestamp(tx["blockTime"], datetime.timezone.utc).isoformat(),
        "url": "https://solscan.io/tx/" + signature,
    })
assert len(rows) == 7, "The expected source lists seven transactions"
verified = decimal.Decimal(raw_total) / 1_000_000
result = {
    "mint": MINT,
    "observed_at_utc": records["observed_at_utc"],
    "source_rpc": records["rpc"],
    "commitment": "finalized",
    "verified_listed_burns_net": str(verified),
    "previously_reported_net": "100000000",
    "difference_from_previous_claim_net": str(decimal.Decimal(100_000_000) - verified),
    "scope": "Only the seven transactions listed in BURNS.md. Not an exhaustive token history audit.",
    "records": rows,
}
print(json.dumps(result, indent=2))
